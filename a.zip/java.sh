#!/bin/sh
unzip mcl-1.2.3.zip
sleep 5s
#tar xJvf jvdroid_termux_openjdk_11.0.1.tar.xz
#export PATH="$PATH:bin"
#export LD_LIBRARY_PATH="lib:lib/jli"
#java
#echo PATH="$PATH:bin"
#cho LD_LIBRARY_PATH="lib:lib/jli"
echo -----等待执行完毕输入exit---------
chmod +x ./mcl
./mcl
clear
echo -----等待执行完毕输入exit---------
sleep 3s
cp mirai-api-http-v2.5.0.mirai.jar plugins
./mcl
cp setting.yml config/net.mamoe.mirai-api-http
./mcl



